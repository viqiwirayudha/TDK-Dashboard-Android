package com.tigadaunkapuas.dashboard;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceResponse;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.ImageButton;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.io.File;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://dashboard-operasional.tigadaunkapuasplasma.workers.dev/";
    private static final int FILE_CHOOSER_REQUEST = 101;
    private WebView webView;
    private ProgressBar progressBar;
    private TextView connectionBanner;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences preferences;
    private File offlineArchive;
    private boolean fallbackShown = false;
    private boolean backPressedOnce = false;
    private ConnectivityManager.NetworkCallback networkCallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        connectionBanner = findViewById(R.id.connectionBanner);
        preferences = getSharedPreferences("tdk_dashboard", MODE_PRIVATE);
        offlineArchive = new File(getFilesDir(), "tdk_dashboard_offline.mht");
        ImageButton refreshButton = findViewById(R.id.refreshButton);
        ImageButton shareButton = findViewById(R.id.shareButton);
        refreshButton.setOnClickListener(v -> loadDashboard(true));
        shareButton.setOnClickListener(v -> shareDashboard());
        configureWebView();
        registerNetworkMonitor();
        if (state == null) {
            if (!preferences.getBoolean("first_launch_done", false)) {
                Toast.makeText(this, "Menyiapkan dashboard untuk penggunaan online dan offline…", Toast.LENGTH_LONG).show();
                preferences.edit().putBoolean("first_launch_done", true).apply();
            }
            loadDashboard(false);
        } else webView.restoreState(state);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        s.setCacheMode(isOnline() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("https".equals(scheme)) return false;
                if ("http".equals(scheme)) {
                    Toast.makeText(MainActivity.this, "Tautan HTTP tidak aman diblokir", Toast.LENGTH_SHORT).show();
                    return true;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Aplikasi tujuan tidak tersedia", Toast.LENGTH_SHORT).show(); }
                return true;
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && !fallbackShown) {
                    fallbackShown = true;
                    if (offlineArchive.exists()) view.loadUrl(Uri.fromFile(offlineArchive).toString());
                    else showOfflinePage();
                }
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith(HOME_URL) && isOnline()) {
                    String stamp = new SimpleDateFormat("dd-MM-yyyy HH:mm", new Locale("id", "ID")).format(new Date());
                    preferences.edit().putString("last_sync", stamp).apply();
                    fallbackShown = false;
                    updateConnectionBanner();
                    view.postDelayed(() -> view.saveWebArchive(offlineArchive.getAbsolutePath(), false, null), 3000);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
                progressBar.setVisibility(progress < 100 ? View.VISIBLE : View.GONE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (ActivityNotFoundException e) { fileCallback = null; return false; }
            }
        });

        webView.setDownloadListener((url, userAgent, disposition, mimeType, length) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);
                request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, android.webkit.URLUtil.guessFileName(url, disposition, mimeType));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "File sedang diunduh", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        });
    }

    private void loadDashboard(boolean forceNetwork) {
        fallbackShown = false;
        if (!isOnline() && offlineArchive.exists()) {
            webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            updateConnectionBanner();
            webView.loadUrl(Uri.fromFile(offlineArchive).toString());
            return;
        }
        if (forceNetwork && isOnline()) webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        else webView.getSettings().setCacheMode(isOnline() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        updateConnectionBanner();
        webView.loadUrl(HOME_URL);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network network = cm.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private void updateConnectionBanner() {
        if (isOnline()) {
            connectionBanner.setVisibility(View.GONE);
        } else {
            String lastSync = preferences.getString("last_sync", "belum pernah tersinkron");
            connectionBanner.setText("Mode Offline — data terakhir: " + lastSync);
            connectionBanner.setVisibility(View.VISIBLE);
        }
    }

    private void registerNetworkMonitor() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                runOnUiThread(() -> {
                    updateConnectionBanner();
                    if (fallbackShown) loadDashboard(false);
                });
            }
            @Override public void onLost(Network network) {
                runOnUiThread(() -> {
                    webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                    updateConnectionBanner();
                });
            }
        };
        cm.registerNetworkCallback(new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), networkCallback);
    }

    private void shareDashboard() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "TDK Dashboard Operasional");
        send.putExtra(Intent.EXTRA_TEXT, "Dashboard Operasional PT. Tigadaun Kapuas\n" + HOME_URL);
        startActivity(Intent.createChooser(send, "Bagikan dashboard melalui"));
    }

    private void showOfflinePage() {
        String lastSync = preferences.getString("last_sync", "belum pernah tersinkron");
        String html = "<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<body style='margin:0;font-family:sans-serif;background:#f4f7fb;color:#17233b;display:grid;place-items:center;height:100vh'>" +
                "<div style='text-align:center;padding:28px'><div style='font-size:54px'>☁</div>" +
                "<h2>Koneksi tidak tersedia</h2><p>Cache halaman belum lengkap.<br>Sinkronisasi terakhir: " + lastSync + "</p>" +
                "<button onclick=\"location.href='" + HOME_URL + "'\" style='border:0;border-radius:12px;padding:13px 22px;background:#188a10;color:white;font-weight:bold'>Coba Lagi</button>" +
                "</div></body></html>";
        webView.loadDataWithBaseURL(HOME_URL, html, "text/html", "UTF-8", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else if (backPressedOnce) {
            super.onBackPressed();
        } else {
            backPressedOnce = true;
            Toast.makeText(this, "Tekan kembali sekali lagi untuk keluar", Toast.LENGTH_SHORT).show();
            new Handler(Looper.getMainLooper()).postDelayed(() -> backPressedOnce = false, 2000);
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        if (networkCallback != null) {
            try { ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(networkCallback); }
            catch (Exception ignored) { }
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
