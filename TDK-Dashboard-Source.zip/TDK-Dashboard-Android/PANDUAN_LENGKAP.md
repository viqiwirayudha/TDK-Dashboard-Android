# Panduan TDK Dashboard Android v3.0

## A. Memperbarui source di GitHub

1. Ekstrak paket `TDK-Dashboard-Professional-v3.0.0.zip`.
2. Buka repository `viqiwirayudha/TDK-Dashboard-Android`.
3. Pilih `Add file` lalu `Upload files`.
4. Unggah folder `TDK-Dashboard-Android` dari paket versi 3.0 dan izinkan GitHub mengganti file lama.
5. Isi pesan commit `Update aplikasi offline v3.0` lalu pilih `Commit changes`.

## B. Membuat APK tanpa Android Studio

1. Buka tab `Actions` pada repository.
2. Pilih workflow `Build APK`.
3. Tekan `Run workflow`, lalu tekan tombol hijau `Run workflow`.
4. Tunggu tanda hijau.
5. Buka hasil build dan unduh artifact `TDK-Dashboard-APK`.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

## C. Memasang APK

1. Salin atau unduh APK ke HP Android.
2. Buka APK dan izinkan instalasi dari sumber tersebut bila Android meminta.
3. Jika versi lama sudah terpasang, APK dengan package ID yang sama akan memperbaruinya tanpa menghapus data aplikasi.
4. Buka aplikasi saat internet tersedia dan tunggu dashboard selesai dimuat minimal sekali.

## D. Menguji mode offline

1. Saat online, buka seluruh halaman dashboard yang penting dan tunggu sekitar 10 detik.
2. Aktifkan mode pesawat.
3. Tutup aplikasi dari Recent Apps lalu buka kembali.
4. Pastikan banner `Mode Offline` tampil dan halaman terakhir dapat dibuka.
5. Matikan mode pesawat; aplikasi akan kembali memuat versi online.

## E. Perilaku data

- Online: HTML dan data Supabase terbaru dimuat.
- Offline: aplikasi menampilkan arsip/cache terakhir.
- Perubahan HTML Cloudflare tidak memerlukan APK baru.
- Perubahan nama, logo, URL, izin, keamanan, atau fungsi Android memerlukan APK baru.
- Pembaruan dashboard dilakukan melalui tombol refresh khusus di kanan atas; gerakan tarik layar ke bawah tetap digunakan untuk scrolling biasa.

## F. Tahap lanjutan yang memerlukan source HTML/backend

1. Service Worker untuk cache semua aset secara terkontrol.
2. IndexedDB untuk menyimpan dataset Supabase terakhir dan menjalankan filter penuh secara offline.
3. Login berdasarkan peran Direksi, Manager, Asisten, dan Admin.
4. Antrean upload offline yang dikirim otomatis saat koneksi kembali.
5. Notifikasi target, biaya tinggi, dan pekerjaan tertunda.
6. Audit log aktivitas pengguna dan crash reporting.
